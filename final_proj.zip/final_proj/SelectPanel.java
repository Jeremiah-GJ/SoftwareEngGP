//SelectPanel.java

package final_proj;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class SelectPanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private String selectedDeck;

    public SelectPanel(CardLayout cardLayout, JPanel container) {
        // Set background color to neutral
        setBackground(Color.DARK_GRAY);
        setLayout(new GridLayout(2, 2, 20, 20)); // 2x2 grid with spacing

        // Deck information
        String[] deckNames = {"Yugi", "Joey", "Kaiba", "Weevil"};
        String[] imagePaths = {
                "/final_proj/Yugi_Portrait.png",
                "/final_proj/Joey_Portrait.png",
                "/final_proj/Kaiba_Portrait.png",
                "/final_proj/Weevil_Portrait.png"
        };

        // Add components for each deck
        for (int i = 0; i < deckNames.length; i++) {
            JPanel deckPanel = new JPanel(new BorderLayout());
            deckPanel.setBackground(Color.DARK_GRAY); // Same as the main background

            // Load and scale character image
            URL imageURL = getClass().getResource(imagePaths[i]);
            JLabel characterLabel;
            if (imageURL != null) {
                ImageIcon characterImage = new ImageIcon(imageURL);
                characterImage = scaleImageIcon(characterImage, 200, 200); // Adjust image size
                characterLabel = new JLabel(characterImage);
            } else {
                System.out.println("Image not found: " + imagePaths[i]);
                characterLabel = new JLabel("Image not found");
                characterLabel.setForeground(Color.WHITE); // Make text readable on dark background
            }
            characterLabel.setHorizontalAlignment(JLabel.CENTER);
            deckPanel.add(characterLabel, BorderLayout.CENTER);

            // Add "Select" button
            JButton selectButton = new JButton("Select");
            final String deckName = deckNames[i];
            selectButton.addActionListener(e -> {
                selectedDeck = deckName;
                System.out.println("Selected Deck: " + selectedDeck);
                cardLayout.show(container, "GamePanel"); // Proceed to the game panel
            });
            deckPanel.add(selectButton, BorderLayout.SOUTH);

            // Add the deck panel to the SelectPanel
            add(deckPanel);
        }

        // Set preferred size
        setPreferredSize(new Dimension(1000, 800)); // Updated dimensions to fit everything
    }

    private ImageIcon scaleImageIcon(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image scaledImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImg);
    }

    public String getSelectedDeck() {
        return selectedDeck;
    }
}


